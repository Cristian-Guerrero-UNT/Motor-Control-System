# BOOST-DRV8711
Arduino Library + Sketches for BOOST-DRV8711 Module

These are the Arduino sketches and Library used in my homebuilt CNC Controller,
containing 3 Boost-DRV8711 Modules managed by an Arduino Pro Mini.

A second Arduino running GRBL provides the step & direction signals.
