# Breadboard-Demonstration
Code needed to operate two BOOST-DRV8711 evaluation boards and a MIC4606.
Files will be separated into the 'Libraries' and 'Sketches' that the Arduino IDE can work with.
Note the 'src' directory needs to be copied into whichever sketch folder will be used to test with.
